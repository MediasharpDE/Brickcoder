/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * createnbc.h
 * Copyright (C) 2012 Malte Brockmeier <malte.brockmeier@googlemailcom>
 * 
 * CreateNBC is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * CreateNBC is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef _CREATENBC_
#define _CREATENBC_

#include <gtk/gtk.h>

G_BEGIN_DECLS

#define CREATENBC_TYPE_APPLICATION             (createnbc_get_type ())
#define CREATENBC_APPLICATION(obj)             (G_TYPE_CHECK_INSTANCE_CAST ((obj), CREATENBC_TYPE_APPLICATION, Createnbc))
#define CREATENBC_APPLICATION_CLASS(klass)     (G_TYPE_CHECK_CLASS_CAST ((klass), CREATENBC_TYPE_APPLICATION, CreatenbcClass))
#define CREATENBC_IS_APPLICATION(obj)          (G_TYPE_CHECK_INSTANCE_TYPE ((obj), CREATENBC_TYPE_APPLICATION))
#define CREATENBC_IS_APPLICATION_CLASS(klass)  (G_TYPE_CHECK_CLASS_TYPE ((klass), CREATENBC_TYPE_APPLICATION))
#define CREATENBC_APPLICATION_GET_CLASS(obj)   (G_TYPE_INSTANCE_GET_CLASS ((obj), CREATENBC_TYPE_APPLICATION, CreatenbcClass))

typedef struct _CreatenbcClass CreatenbcClass;
typedef struct _Createnbc Createnbc;
typedef struct _CreatenbcPrivate CreatenbcPrivate;

struct _CreatenbcClass
{
	GtkApplicationClass parent_class;
};

struct _Createnbc
{
	GtkApplication parent_instance;

	CreatenbcPrivate *priv;

};

GType createnbc_get_type (void) G_GNUC_CONST;
Createnbc *createnbc_new (void);

/* Callbacks */

G_END_DECLS

#endif /* _APPLICATION_H_ */
