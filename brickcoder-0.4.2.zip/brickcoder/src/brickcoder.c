/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * brickcoder.c
 * Copyright (C) 2012 Malte Brockmeier <malte.brockmeier@googlemail.com>
 * 
 * Brickcoder is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Brickcoder is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include "brickcoder.h"
#include <stdio.h>
#include <glib/gi18n.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>
#include "IO.h"
#include "Compile.h"
#include "functions.h"
#include "Print.h"


/* For testing propose use the local (not installed) ui file */
/* #define UI_FILE PACKAGE_DATA_DIR"/ui/brickcoder.ui" */
#define UI_FILE "src/brickcoder.ui"
#define TOP_WINDOW "window"


G_DEFINE_TYPE (Brickcoder, brickcoder, GTK_TYPE_APPLICATION);


/* Define the private structure in the .c file */
#define BRICKCODER_GET_PRIVATE(obj) (G_TYPE_INSTANCE_GET_PRIVATE((obj), BRICKCODER_TYPE_APPLICATION, BrickcoderPrivate))


GtkTextBuffer *savebuffer;
gchar *openfile;
GtkTextIter *start_find, *end_find;
gchar *textineditor;
gboolean *saved = FALSE;
FILE *fp;

struct _BrickcoderPrivate
{
	/* ANJUTA: Widgets declaration for brickcoder.ui - DO NOT REMOVE */
	GtkWidget* imagemenuitem2;
};

void on_toolbutton1_clicked(GtkToolButton *toolbutton, gpointer data)
{
	newfile(toolbutton, data);
}

void on_imagemenuitem2_activate(GtkMenuItem *menuitem, gpointer data)
{
	openafilemenubutton(menuitem, data);
}

void on_imagemenuitem5_activate(GtkMenuItem *menuitem, gpointer data)
{
	system("killall brickcoder");
}

void on_imagemenuitem7_activate(GtkMenuItem *menuitem, gpointer data)
{
	textcopymenu(menuitem, data);
}

void on_imagemenuitem8_activate(GtkMenuItem *menuitem, gpointer data)
{
	textpastemenu(menuitem, data);
}

void on_imagemenuitem6_activate(GtkMenuItem *menuitem, gpointer data)
{
	textcutmenu(menuitem, data);
}



void on_imagemenuitem1_activate(GtkMenuItem *menuitem, gpointer data)
{
   
	newfilemenu(menuitem, data);
	
}

void on_imagemenuitem3_activate(GtkMenuItem *menuitem, gpointer data)
{
	saveafilemenuitem(menuitem, data);
}

void on_toolbutton2_clicked(GtkToolButton *toolbutton, gpointer data)
{
	openafiletoolbutton (toolbutton, data);
	
	
}

void on_toolbutton10_clicked(GtkToolButton *toolbutton, gpointer data)
{
	compileanddownload(toolbutton, data);
}

void on_toolbutton12_clicked(GtkToolButton *toolbutton, gpointer data)
{
  
  about(toolbutton, data);

}

void on_toolbutton11_clicked(GtkToolButton *toolbutton, gpointer data)
{
	compile(toolbutton, data);

}




void on_toolbutton3_clicked(GtkToolButton *toolbutton, gpointer data)
{   
	saveafiletoolbutton(toolbutton, data);
        
       


}



void on_toolbutton6_clicked(GtkToolButton *toolbutton, gpointer data)
{
	textcopy(toolbutton, data);
  
}

void on_toolbutton7_clicked(GtkToolButton *toolbutton, gpointer data)
{
	textpaste(toolbutton, data);
  
}

void on_toolbutton8_clicked(GtkToolButton *toolbutton, gpointer data)
{
	textcut(toolbutton, data);
}

/* Create a new window loading a file */
static void
brickcoder_new_window (GApplication *app,
                           GFile        *file)
{
	GtkWidget *window;

	GtkBuilder *builder;
	GError* error = NULL;

	BrickcoderPrivate *priv = BRICKCODER_GET_PRIVATE(app);

	/* Load UI from file */
	builder = gtk_builder_new ();
	if (!gtk_builder_add_from_file (builder, UI_FILE, &error))
	{
		g_critical ("Couldn't load builder file: %s", error->message);
		g_error_free (error);
	}

	/* Auto-connect signal handlers */
	gtk_builder_connect_signals (builder, app);

	/* Get the window object from the ui file */
	window = GTK_WIDGET (gtk_builder_get_object (builder, TOP_WINDOW));
        if (!window)
        {
                g_critical ("Widget \"%s\" is missing in file %s.",
				TOP_WINDOW,
				UI_FILE);
        }

	
	/* ANJUTA: Widgets initialization for brickcoder.ui - DO NOT REMOVE */
	priv->imagemenuitem2 = GTK_WIDGET (gtk_builder_get_object(builder, "imagemenuitem2"));

	g_object_unref (builder);
	
	
	gtk_window_set_application (GTK_WINDOW (window), GTK_APPLICATION (app));
	if (file != NULL)
	{
		/* TODO: Add code here to open the file in the new window */
	}
	gtk_widget_show_all (GTK_WIDGET (window));
}


/* GApplication implementation */
static void
brickcoder_activate (GApplication *application)
{
  brickcoder_new_window (application, NULL);
}

static void
brickcoder_open (GApplication  *application,
                     GFile        **files,
                     gint           n_files,
                     const gchar   *hint)
{
  gint i;

  for (i = 0; i < n_files; i++)
    brickcoder_new_window (application, files[i]);
}

static void
brickcoder_init (Brickcoder *object)
{

}

static void
brickcoder_finalize (GObject *object)
{

	G_OBJECT_CLASS (brickcoder_parent_class)->finalize (object);
}

static void
brickcoder_class_init (BrickcoderClass *klass)
{
	G_APPLICATION_CLASS (klass)->activate = brickcoder_activate;
	G_APPLICATION_CLASS (klass)->open = brickcoder_open;

	g_type_class_add_private (klass, sizeof (BrickcoderPrivate));

	G_OBJECT_CLASS (klass)->finalize = brickcoder_finalize;
}

Brickcoder *
brickcoder_new (void)
{
	g_type_init ();

	return g_object_new (brickcoder_get_type (),
	                     "application-id", "org.gnome.brickcoder",
	                     "flags", G_APPLICATION_HANDLES_OPEN,
	                     NULL);
}
