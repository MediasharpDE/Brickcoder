#ifndef _IO_H_
#define _IO_H_

void openafiletoolbutton(GtkToolButton *toolbutton, gpointer data);
void openafiletoolmenu(GtkMenuItem *menuitem, gpointer data);
void saveafiletoolbutton(GtkToolButton *toolbutton, gpointer data);
void saveafilemenuitem(GtkMenuItem *menuitem, gpointer data);
gchar *get_save_filename();
#endif