#include "brickcoder.h"
#include <stdio.h>
#include <glib/gi18n.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>
#include "IO.h"
#include "Compile.h"

GtkTextBuffer *newbuffer;

void newfile(GtkToolButton *toolbutton, gpointer data)
{
	
	newbuffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data));
	gtk_text_buffer_set_text (newbuffer, "", -1);
	openfile = "";
}

void newfilemenu(GtkMenuItem *menuitem, gpointer data)
{
	
	newbuffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data));
	gtk_text_buffer_set_text (newbuffer, "", -1);
}

void textcopymenu(GtkMenuItem *menuitem, gpointer data)
{
	GtkTextBuffer *textbuffer = NULL;
  g_assert (GTK_IS_TEXT_VIEW (data));
  /* Aktuellen Puffer für die Textansicht ermitteln */
  textbuffer=gtk_text_view_get_buffer(GTK_TEXT_VIEW(data));
  /* Text im Puffer in die Zwischenablage kopieren */
  gtk_text_buffer_copy_clipboard (textbuffer,
                                  gtk_clipboard_get (GDK_NONE));

}

void textcopy(GtkToolButton *toolbutton, gpointer data)
{
	GtkTextBuffer *textbuffer = NULL;
  g_assert (GTK_IS_TEXT_VIEW (data));
  /* Aktuellen Puffer für die Textansicht ermitteln */
  textbuffer=gtk_text_view_get_buffer(GTK_TEXT_VIEW(data));
  /* Text im Puffer in die Zwischenablage kopieren */
  gtk_text_buffer_copy_clipboard (textbuffer,
                                  gtk_clipboard_get (GDK_NONE));

}

void textcut(GtkToolButton *toolbutton, gpointer data)
{
	GtkTextBuffer *textbuffer = NULL;
  g_assert (GTK_IS_TEXT_VIEW (data));
  /* Aktuellen Puffer für die Textansicht ermitteln */
  textbuffer=gtk_text_view_get_buffer(GTK_TEXT_VIEW(data));
  /* Text im Puffer löschen und in Zwischenablage legen */
  gtk_text_buffer_cut_clipboard (textbuffer,
                             gtk_clipboard_get (GDK_NONE), TRUE);
}

void textcutmenu(GtkMenuItem *menuitem, gpointer data)
{
	GtkTextBuffer *textbuffer = NULL;
  g_assert (GTK_IS_TEXT_VIEW (data));
  /* Aktuellen Puffer für die Textansicht ermitteln */
  textbuffer=gtk_text_view_get_buffer(GTK_TEXT_VIEW(data));
  /* Text im Puffer löschen und in Zwischenablage legen */
  gtk_text_buffer_cut_clipboard (textbuffer,
                             gtk_clipboard_get (GDK_NONE), TRUE);
}

void textpaste(GtkToolButton *toolbutton, gpointer data)
{
	GtkTextBuffer *textbuffer = NULL;
  g_assert (GTK_IS_TEXT_VIEW (data));
  /* Aktuellen Puffer für die Textansicht ermitteln */
  textbuffer=gtk_text_view_get_buffer(GTK_TEXT_VIEW(data));
  /* Text aus der Zwischenablage  (falls vorhanden) */
  /*  in den Puffer kopieren                        */
  gtk_text_buffer_paste_clipboard (textbuffer,
                                   gtk_clipboard_get (GDK_NONE),
                                   NULL, TRUE);
}

void textpastemenu(GtkMenuItem *menuitem, gpointer data)
{
	GtkTextBuffer *textbuffer = NULL;
  g_assert (GTK_IS_TEXT_VIEW (data));
  /* Aktuellen Puffer für die Textansicht ermitteln */
  textbuffer=gtk_text_view_get_buffer(GTK_TEXT_VIEW(data));
  /* Text aus der Zwischenablage  (falls vorhanden) */
  /*  in den Puffer kopieren                        */
  gtk_text_buffer_paste_clipboard (textbuffer,
                                   gtk_clipboard_get (GDK_NONE),
                                   NULL, TRUE);
}

void about(GtkToolButton *toolbutton, gpointer data)
{
	GdkPixbuf *pixbuf = gdk_pixbuf_new_from_file("development-2.png", NULL);

  GtkWidget *dialog = gtk_about_dialog_new();
  gtk_about_dialog_set_program_name(GTK_ABOUT_DIALOG(dialog), "Brickcoder");
  gtk_about_dialog_set_version(GTK_ABOUT_DIALOG(dialog), "0.4.2"); 
  gtk_about_dialog_set_copyright(GTK_ABOUT_DIALOG(dialog), 
      "(c) 2012 Malte Brockmeier");
  gtk_about_dialog_set_license(GTK_ABOUT_DIALOG(dialog), "Brickcoder ist freie Software. Sie können es unter den Bedingungen der GNU General Public License, wie von der Free Software Foundation veröffentlicht, weitergeben und/oder modifizieren, entweder gemäß Version 2 der Lizenz oder (nach Ihrer Option) jeder späteren Version.\n \n Die Veröffentlichung von Brickcoder erfolgt in der Hoffnung, dass es Ihnen von Nutzen sein wird, aber OHNE IRGENDEINE GARANTIE, sogar ohne die implizite Garantie der MARKTREIFE oder der VERWENDBARKEIT FÜR EINEN BESTIMMTEN ZWECK. Details finden Sie in der GNU General Public License.\n \n Sie sollten ein Exemplar der GNU General Public License zusammen mit Brickcoder erhalten haben. Falls nicht, schreiben Sie an die Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02111-1307 USA.");
  gtk_about_dialog_set_wrap_license(GTK_ABOUT_DIALOG(dialog), TRUE);
gtk_about_dialog_set_comments(GTK_ABOUT_DIALOG(dialog), 
     "Brickcoder ist ein Programm, um NXT-Programme mithilfe von not eXactly C zu schreiben.");
  gtk_about_dialog_set_website(GTK_ABOUT_DIALOG(dialog), 
      "http://www.mediasharp.de");
  gtk_about_dialog_set_logo(GTK_ABOUT_DIALOG(dialog), pixbuf);
  g_object_unref(pixbuf), pixbuf = NULL;
  gtk_dialog_run(GTK_DIALOG (dialog));
  gtk_widget_destroy(dialog);
}	