/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * brickcoder.h
 * Copyright (C) 2012 Malte Brockmeier <malte.brockmeier@googlemail.com>
 * 
 * Brickcoder is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Brickcoder is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef _BRICKCODER_
#define _BRICKCODER_

#include <gtk/gtk.h>

G_BEGIN_DECLS

#define BRICKCODER_TYPE_APPLICATION             (brickcoder_get_type ())
#define BRICKCODER_APPLICATION(obj)             (G_TYPE_CHECK_INSTANCE_CAST ((obj), BRICKCODER_TYPE_APPLICATION, Brickcoder))
#define BRICKCODER_APPLICATION_CLASS(klass)     (G_TYPE_CHECK_CLASS_CAST ((klass), BRICKCODER_TYPE_APPLICATION, BrickcoderClass))
#define BRICKCODER_IS_APPLICATION(obj)          (G_TYPE_CHECK_INSTANCE_TYPE ((obj), BRICKCODER_TYPE_APPLICATION))
#define BRICKCODER_IS_APPLICATION_CLASS(klass)  (G_TYPE_CHECK_CLASS_TYPE ((klass), BRICKCODER_TYPE_APPLICATION))
#define BRICKCODER_APPLICATION_GET_CLASS(obj)   (G_TYPE_INSTANCE_GET_CLASS ((obj), BRICKCODER_TYPE_APPLICATION, BrickcoderClass))

typedef struct _BrickcoderClass BrickcoderClass;
typedef struct _Brickcoder Brickcoder;
typedef struct _BrickcoderPrivate BrickcoderPrivate;
gchar *openfile;
gboolean *saved;
struct _BrickcoderClass
{
	GtkApplicationClass parent_class;
};

struct _Brickcoder
{
	GtkApplication parent_instance;

	BrickcoderPrivate *priv;

};

GType brickcoder_get_type (void) G_GNUC_CONST;
Brickcoder *brickcoder_new (void);

/* Callbacks */

G_END_DECLS

#endif /* _APPLICATION_H_ */
