/* (C) 2012 Malte Brockmeier <malte.brockmeier@googlemail.com> - Licensed under GPL (GNU General Public License).
 * In dieser Datei werden Funktionen für Brickcoder definiert, worüber Dateien geöffnet, gelesen und geschrieben werden.
 * 
*/

#include "brickcoder.h"
#include <stdio.h>
#include <glib/gi18n.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>
#include "IO.h"

GtkTextBuffer *newbuffer;
GtkTextBuffer *savebuffer;
GtkTextBuffer *openbuffer;
GtkTextIter *start_find, *end_find;
gchar *textineditor;
gchar *openfiler = NULL;
FILE *fp;

// Öffnen von Dateien über ToolButton
void openafiletoolbutton(GtkToolButton *toolbutton, gpointer data)
{
	char *filename;
    openbuffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data));
	
	GtkWidget *dialog;
	dialog = gtk_file_chooser_dialog_new ("Öffnen...",
				      NULL,
				      GTK_FILE_CHOOSER_ACTION_OPEN,
				      GTK_STOCK_CANCEL, GTK_RESPONSE_CANCEL,
				      GTK_STOCK_OPEN, GTK_RESPONSE_ACCEPT,
				      NULL);
	if (gtk_dialog_run (GTK_DIALOG (dialog)) == GTK_RESPONSE_ACCEPT)
	 {
    
    filename = gtk_file_chooser_get_filename (GTK_FILE_CHOOSER (dialog));
    GError *error;
	FILE *fp;
	gboolean read_file_status;
	gchar *file_buffer;
	fp = fopen (filename, "rt");
	read_file_status=g_file_get_contents (filename,&file_buffer,NULL, &error);
	if (read_file_status == FALSE) {

	}
	gtk_text_buffer_set_text (openbuffer, file_buffer,-1);
	fclose(fp);
	openfiler = filename;
	openfile = filename;
	}
	gtk_widget_destroy (dialog);
	
}

//Öffnen von Dateien über MenuItem
void openafilemenubutton(GtkWidget *widget, gpointer data)
{
    openbuffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data));
	
	GtkWidget *dialog;
	dialog = gtk_file_chooser_dialog_new ("Öffnen...",
				      NULL,
				      GTK_FILE_CHOOSER_ACTION_OPEN,
				      GTK_STOCK_CANCEL, GTK_RESPONSE_CANCEL,
				      GTK_STOCK_OPEN, GTK_RESPONSE_ACCEPT,
				      NULL);
	if (gtk_dialog_run (GTK_DIALOG (dialog)) == GTK_RESPONSE_ACCEPT)
	 {
    char *filename;
    filename = gtk_file_chooser_get_filename (GTK_FILE_CHOOSER (dialog));
    GError *error;
	FILE *fp;
	gboolean read_file_status;
	gchar *file_buffer;
	fp = fopen (filename, "rt");
	read_file_status=g_file_get_contents (filename,&file_buffer,NULL, &error);
	if (read_file_status == FALSE) {

	}
	gtk_text_buffer_set_text (openbuffer, file_buffer,-1);
	fclose(fp);
	openfiler = filename;
	openfile = filename;
	}
	gtk_widget_destroy (dialog);
}

//Speichern von Dateien über ToolButton
void saveafiletoolbutton(GtkToolButton *toolbutton, gpointer data)
{
	GError                  *err=NULL;
        gchar                   *status;
        gchar                   *text;
        gboolean                result;
        GtkTextBuffer           *buffer;
        GtkTextIter             start, end;
		gchar *filename;
		filename = get_save_filename();
        
        /* add Saving message to status bar and ensure GUI is current */
        if (filename != NULL)
            status = g_strdup_printf ("Speichern %s...", filename);
        else
            status = g_strdup_printf ("Speichern %s...", filename);
            
        
        g_free (status);
        while (gtk_events_pending()) gtk_main_iteration();
        
        /* disable text view and get contents of buffer */ 
        gtk_widget_set_sensitive (data, FALSE);
        buffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data));
        gtk_text_buffer_get_start_iter (buffer, &start);
        gtk_text_buffer_get_end_iter (buffer, &end);
        text = gtk_text_buffer_get_text (buffer, &start, &end, FALSE);       
        gtk_text_buffer_set_modified (buffer, FALSE);
        gtk_widget_set_sensitive (data, TRUE);
        
        /* set the contents of the file to the text from the buffer */
        if (filename != NULL)        
                result = g_file_set_contents (filename, text, -1, &err);
        else
                result = g_file_set_contents (filename, text, -1, &err);
	
        openfile = filename;
        if (result == FALSE)
        {
                /* error saving file, show message to user */
                
        }        
        
        /* don't forget to free that memory! */ 
        g_free (text); 

}

//Speichern von Dateien über ToolButton
void saveafilemenuitem(GtkMenuItem *menuitem, gpointer data)
{
	GError                  *err=NULL;
        gchar                   *status;
        gchar                   *text;
        gboolean                result;
        GtkTextBuffer           *buffer;
        GtkTextIter             start, end;
		gchar *filename;
		filename = get_save_filename();
        
        /* add Saving message to status bar and ensure GUI is current */
        if (filename != NULL)
            status = g_strdup_printf ("Speichern %s...", filename);
        else
            status = g_strdup_printf ("Speichern %s...", filename);
            
        
        g_free (status);
        while (gtk_events_pending()) gtk_main_iteration();
        
        /* disable text view and get contents of buffer */ 
        gtk_widget_set_sensitive (data, FALSE);
        buffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data));
        gtk_text_buffer_get_start_iter (buffer, &start);
        gtk_text_buffer_get_end_iter (buffer, &end);
        text = gtk_text_buffer_get_text (buffer, &start, &end, FALSE);       
        gtk_text_buffer_set_modified (buffer, FALSE);
        gtk_widget_set_sensitive (data, TRUE);
        
        /* set the contents of the file to the text from the buffer */
        if (filename != NULL)        
                result = g_file_set_contents (filename, text, -1, &err);
        else
                result = g_file_set_contents (filename, text, -1, &err);
	
        openfile = filename;
        if (result == FALSE)
        {
                /* error saving file, show message to user */
                
        }        
        
        /* don't forget to free that memory! */ 
        g_free (text); 

}

gchar *
get_save_filename ()
{
        GtkWidget               *chooser;
        gchar                   *filename=NULL;
                
        chooser = gtk_file_chooser_dialog_new ("Save File...",
                                               NULL,
                                               GTK_FILE_CHOOSER_ACTION_SAVE,
                                               GTK_STOCK_CANCEL, GTK_RESPONSE_CANCEL,
                                               GTK_STOCK_SAVE, GTK_RESPONSE_OK,
                                               NULL);
                                               
        if (gtk_dialog_run (GTK_DIALOG (chooser)) == GTK_RESPONSE_OK)
        {
                filename = gtk_file_chooser_get_filename (GTK_FILE_CHOOSER (chooser));
        }
        
        gtk_widget_destroy (chooser);
        return filename;
}