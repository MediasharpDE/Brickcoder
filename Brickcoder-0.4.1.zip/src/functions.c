#include "brickcoder.h"
#include <stdio.h>
#include <glib/gi18n.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>
#include "IO.h"
#include "Compile.h"

GtkTextBuffer *newbuffer;

void newfile(GtkToolButton *toolbutton, gpointer data)
{
	
	newbuffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW (data));
	gtk_text_buffer_set_text (newbuffer, "", -1);
}