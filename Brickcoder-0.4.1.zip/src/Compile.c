/*
 * Compile.c
 *
 * Copyright (C) 2012 - Malte Brockmeier
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

#include "brickcoder.h"
#include <stdio.h>
#include <glib/gi18n.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>
#include "IO.h"
#include "Compile.h"



void compileanddownload(GtkToolButton *toolbutton, gpointer data)
{
	
	if (openfile != NULL)
	    {
			GtkWidget *hinweis;
  hinweis = gtk_message_dialog_new(NULL,
            GTK_DIALOG_DESTROY_WITH_PARENT,
            GTK_MESSAGE_INFO,
            GTK_BUTTONS_OK,
            "Zum Übertragen muss der NXT eingeschaltet sein und mit dem mitgelieferten USB-Kabel an den PC angeschlossen sein.", "Hinweis");
  gtk_window_set_title(GTK_WINDOW(hinweis), "Hinweis");
  gtk_dialog_run(GTK_DIALOG(hinweis));
  gtk_widget_destroy(hinweis);
	char string[80];
	
	strcpy(string, "gksudo -- nbc -S=USB -EF -r ");
	
	strcat(string, openfile);
	

	system(string);

	

  GtkWidget *dialog;
  dialog = gtk_message_dialog_new(NULL,
            GTK_DIALOG_DESTROY_WITH_PARENT,
            GTK_MESSAGE_INFO,
            GTK_BUTTONS_OK,
            "Das Programm wurde erfolgreich kompiliert und auf den NXT übertragen.", "Download erfolgreich");
  gtk_window_set_title(GTK_WINDOW(dialog), "Vorgang erfolgreich");
  gtk_dialog_run(GTK_DIALOG(dialog));
  gtk_widget_destroy(dialog);
		}
	else
	    {
			GtkWidget *dialog;
  dialog = gtk_message_dialog_new(NULL,
            GTK_DIALOG_DESTROY_WITH_PARENT,
            GTK_MESSAGE_ERROR,
            GTK_BUTTONS_OK,
            "Es sind keine Programmdateien geöffnet.", "Vorgang nicht möglich");
  gtk_window_set_title(GTK_WINDOW(dialog), "Vorgang nicht möglich");
  gtk_dialog_run(GTK_DIALOG(dialog));
  gtk_widget_destroy(dialog);
		}

}

void compileanddownloadmenu(GtkMenuItem *menuitem, gpointer data)
{
	
	if (openfile != NULL)
	    {
			GtkWidget *hinweis;
  hinweis = gtk_message_dialog_new(NULL,
            GTK_DIALOG_DESTROY_WITH_PARENT,
            GTK_MESSAGE_INFO,
            GTK_BUTTONS_OK,
            "Zum Übertragen muss der NXT eingeschaltet sein und mit dem mitgelieferten USB-Kabel an den PC angeschlossen sein.", "Hinweis");
  gtk_window_set_title(GTK_WINDOW(hinweis), "Hinweis");
  gtk_dialog_run(GTK_DIALOG(hinweis));
  gtk_widget_destroy(hinweis);
	char string[80];
	
	strcpy(string, "gksudo -- nbc -S=USB -EF -r ");
	
	strcat(string, openfile);
	

	system(string);

	

  GtkWidget *dialog;
  dialog = gtk_message_dialog_new(NULL,
            GTK_DIALOG_DESTROY_WITH_PARENT,
            GTK_MESSAGE_INFO,
            GTK_BUTTONS_OK,
            "Das Programm wurde erfolgreich kompiliert und auf den NXT übertragen.", "Download erfolgreich");
  gtk_window_set_title(GTK_WINDOW(dialog), "Vorgang erfolgreich");
  gtk_dialog_run(GTK_DIALOG(dialog));
  gtk_widget_destroy(dialog);
		}
	else
	    {
			GtkWidget *dialog;
  dialog = gtk_message_dialog_new(NULL,
            GTK_DIALOG_DESTROY_WITH_PARENT,
            GTK_MESSAGE_ERROR,
            GTK_BUTTONS_OK,
            "Es sind keine Programmdateien geöffnet.", "Vorgang nicht möglich");
  gtk_window_set_title(GTK_WINDOW(dialog), "Vorgang nicht möglich");
  gtk_dialog_run(GTK_DIALOG(dialog));
  gtk_widget_destroy(dialog);
		}

}

void compile(GtkToolButton *toolbutton, gpointer data)
{
	if (openfile != NULL)
	    {
			
	char string[80];
	
	strcpy(string, "gksudo -- nbc -S=USB -EF ");
	
	strcat(string, openfile);
	

	system(string);

	

  GtkWidget *dialog;
  dialog = gtk_message_dialog_new(NULL,
            GTK_DIALOG_DESTROY_WITH_PARENT,
            GTK_MESSAGE_INFO,
            GTK_BUTTONS_OK,
            "Das Programm wurde erfolgreich kompiliert.", "Kompiliert.");
  gtk_window_set_title(GTK_WINDOW(dialog), "Vorgang erfolgreich");
  gtk_dialog_run(GTK_DIALOG(dialog));
  gtk_widget_destroy(dialog);
		}
	else
	    {
			GtkWidget *dialog;
  dialog = gtk_message_dialog_new(NULL,
            GTK_DIALOG_DESTROY_WITH_PARENT,
            GTK_MESSAGE_ERROR,
            GTK_BUTTONS_OK,
            "Es sind keine Programmdateien geöffnet.", "Vorgang nicht möglich");
  gtk_window_set_title(GTK_WINDOW(dialog), "Vorgang nicht möglich");
  gtk_dialog_run(GTK_DIALOG(dialog));
  gtk_widget_destroy(dialog);
		}
}

void compilemenu(GtkMenuItem *menuitem, gpointer data)
{
	if (openfile != NULL)
	    {
			
	char string[80];
	
	strcpy(string, "gksudo -- nbc -S=USB -EF ");
	
	strcat(string, openfile);
	

	system(string);

	

  GtkWidget *dialog;
  dialog = gtk_message_dialog_new(NULL,
            GTK_DIALOG_DESTROY_WITH_PARENT,
            GTK_MESSAGE_INFO,
            GTK_BUTTONS_OK,
            "Das Programm wurde erfolgreich kompiliert.", "Kompiliert.");
  gtk_window_set_title(GTK_WINDOW(dialog), "Vorgang erfolgreich");
  gtk_dialog_run(GTK_DIALOG(dialog));
  gtk_widget_destroy(dialog);
		}
	else
	    {
			GtkWidget *dialog;
  dialog = gtk_message_dialog_new(NULL,
            GTK_DIALOG_DESTROY_WITH_PARENT,
            GTK_MESSAGE_ERROR,
            GTK_BUTTONS_OK,
            "Es sind keine Programmdateien geöffnet.", "Vorgang nicht möglich");
  gtk_window_set_title(GTK_WINDOW(dialog), "Vorgang nicht möglich");
  gtk_dialog_run(GTK_DIALOG(dialog));
  gtk_widget_destroy(dialog);
		}
}